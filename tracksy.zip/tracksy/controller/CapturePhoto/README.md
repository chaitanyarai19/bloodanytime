# CapturePhoto

📌Bootstrap 4:
https://getbootstrap.com/docs/4.6/getting-started/introduction/

📌JQuery:
https://cdnjs.com/libraries/jquery

📌Download website source code:
https://github.com/ParthJT/CapturePhoto.git

📌Subscribe Me
https://www.youtube.com/channel/UCy-gD0_PfmbBtcW4udu0W7g

📌 Follow Me On <br />
LinkedIn: https://www.linkedin.com/in/parth-trambadiya/ <br />
Instagram: https://www.instagram.com/_parth_jt/ <br />
Medium: https://trambadiyaparth.medium.com/ <br />
Portfolio: https://parthtrambadiya.me/ <br />

📌Disclaimer: <br />
This video is solely for educational purposes, use them with your own responsibility. This video might contain some minor mistakes so please take decisions based on your own research and findings. 
This video does not force anything on anyone, decisions are your own. <br /><br />
Any credentials are shown in the video are temporary and already removed, don't complain if those credentials do not work for you, please generate your own credentials for the test.
