<form method="post" id="upload_docs">
    <input name="docs" type="hidden" class="form-control" id="photoStore" value="" required="">
    <input name="topic_id" type="hidden" id="topic_id">
    <input name="name" type="hidden" id="name">
    <input name="capture" type="hidden" value="camera">
</form>