<footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p><i class="fa fa-copyright"></i> Copyright 2022 by Tracksy  </p>
        </div>
      </div>
    </div>
  </footer>

</body>
</html>