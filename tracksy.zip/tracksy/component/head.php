<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <title>TrackSy | Don't think back, just sit and track.</title>
    
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="src/css/bootstrap.min.css">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="src/css/fontawesome.css">
    <link rel="stylesheet" href="src/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="src/css/owl.css">
    <link rel="stylesheet" href="src/css/lightbox.css">

  </head>